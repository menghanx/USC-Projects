export class Favorite {

    constructor(
        public street: string,
        public city: string,
        public state: string,
        public loc: string
    ) { }

}
